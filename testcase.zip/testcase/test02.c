
int a,b,c,d,e,f,g,h,i,j,k,l,m;
int main()
{
	//a=10,b=50,c=4;
	while (a != b+1)
	{
		f = a%10000;
		g = (a-f) / 10000;
		h = f % 1000;
		i = (f - h) % 1000;
		j = h % 100;
		k = (h - j) / 100;
		l = j % 10;
		m = (j - l) / 10;
		if(g == c) e=e+1;
		if(i == c) e=e+1;
		if(k == c) e=e+1;
		if(m == c) e=e+1;
		if(l == c) e=e+1;
		if(g == c || i == c || k == c || m == c || l == c)
		{
			d=d+1;
		}
		a=a+1;
	}
	return 0;
}