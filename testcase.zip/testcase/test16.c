int main()
{
    int n;
    int a;
    int i;
    int k;
    if (n>0)
      for (i=0;i<n;i=i+1)
        if (a>i)
          k=0;
        else
          k=1;
    else
      k=2;
    return 0;
}