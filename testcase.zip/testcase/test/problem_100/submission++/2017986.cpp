#include <bits/stdc++.h>

#define int long long //直接宏定义，省的int改longlong麻烦

using namespace std;

const int N=1e3+7;

const int mod=1e9+7;

int a[N][N],b[N][N];

int c[N][N],m,n,p;

signed main(void) //注意要改成signed，不然过不了编译

{

scanf("%lld%lld%lld",&n,&p,&m); //注意%lld

for(int i=1;i<=n;i++)

for(int j=1;j<=p;j++)

  scanf("%lld",a[i]+j);
for(int i=1;i<=p;i++)

for(int j=1;j<=m;j++)

  scanf("%lld",b[i]+j);
for(int i=1;i<=n;i++)

for(int j=1;j<=m;j++)

  for(int k=1;k<=p;k++)	{

    c[i][j]+=a[i][k]*b[k][j]%mod;  //避免乘法时爆longlong，一边乘一边mod

    c[i][j]+=mod;c[i][j]%=mod;  //处理对负数取mod的问题

  }
for(int i=1;i<=n;i++) {

for(int j=1;j<=m;j++)

  printf("%lld ",c[i][j]);   //因为计算时已经取过mod，输出时就不用再mod一遍

putchar(10);    //也就是换行
}

return 0;

}