#include "shm.h"
using namespace std;

unsigned int plus(unsigned int x, unsigned int y) {
    return x + y;
}