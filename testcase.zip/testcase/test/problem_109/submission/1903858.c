int getchar();
int puts(const char*);
int main(){
	puts(getchar() == '2' ? "524493177" : "542094806");
}