/*#include <bits/stdc++.h>
#define int long long
#define endl '\n'
#define IOS ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
#define lowbit(x) (x&(-x))
using namespace std;
const int N=8e6+10;

const int mod=998244353;
int fa[N];//存储该节点的父节点
int sum[N];
int dist[N];
int find(int x)
{
    if(fa[x]==x)
        return x;
    else {
        int tt=find(fa[x]);
        dist[x]+=dist[fa[x]];
        fa[x]=tt;
        return fa[x];
    }
}
void add(int x,int y)
{
    int xx=find(x);
    int yy=find(y);
    dist[xx]=sum[yy];
    fa[xx]=yy;
    sum[yy]+=sum[xx];
}
void solve()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        fa[i]=i;
    }
    int ans=0;
    while(m--){
        int op,x,y;
        cin>>op>>x>>y;
        if(op==0){
            add(x,y);
        }
        else {
            if(find(x)==find(y)){
                ans=ans*2+1;
            }
            else ans*=2;
            ans%=mod;
        }
    }
    cout << ans%mod <<endl;
}
signed main()
{
    IOS;
    int T=1;
    //cin>>T;
    while(T--){
        solve();
    }
    return 0;
}
*/
//#include <bits/stdc++.h>
#include <iostream>
#include <math.h>
using namespace std;
#define int long long
int n,m,k=1,ern,num;
const int N=4e6+5;
const int M=8e6+5;
const int mod=998244353;
int fa[N];
int st[M];
struct 	node{
	int t,x,y;
}a[N];
int find(int i){
	if(fa[i]==i)	return i;
	else {
        fa[i]=find(fa[i]);
        return fa[i];
	}
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		fa[i]=i;
	}
	for(int i=1;i<=m;i++){
        int t,x,y;
		cin>>t>>x>>y;
		if(t){
			if(find(x)==find(y)){
				st[k++]=1;
			}else{
				st[k++]=0;
			}
		}else{
			int fx=find(x);
			int fy=find(y);
			if(fx!=fy){
				fa[fx]=fy;
			}
		}
	}
	k-=1;
	int ans=0;
	for(int i=1;i<=k;i++){
        if(st[i]){
            ans=(ans*2+1)%mod;
        }
        else ans=ans*2%mod;
	}
	cout<< ans%mod <<endl;
	return 0;
}

