bool _Start;// by Lofty
#include<queue>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
namespace IO
{
	#define TP template<typename T>
	#define TP_ template<typename T,typename ... T_>
	#ifdef DEBUG
	#define gc() (getchar())
	#else
	char buf[1<<20],*p1,*p2;
	#define gc() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<20,stdin),p1==p2)?EOF:*p1++)
	#endif
	#ifdef DEBUG
	void pc(const char &c)
	{O
		putchar(c);
	}
	#else
	char pbuf[1<<20],*pp=pbuf;
	void pc(const char &c)
	{
		if(pp-pbuf==1<<20)
			fwrite(pbuf,1,1<<20,stdout),pp=pbuf;
		*pp++=c;
	}
	struct IO{~IO(){fwrite(pbuf,1,pp-pbuf,stdout);}}_;
	#endif
	TP void read(T &x)
	{
		x=0;static int f;f=0;static char ch;ch=gc();
		for(;ch<'0'||ch>'9';ch=gc())ch=='-'&&(f=1);
		for(;ch>='0'&&ch<='9';ch=gc())x=(x<<1)+(x<<3)+(ch^48);
		f&&(x=-x);
	}
	TP void write(T x)
	{
		if(x<0)
			pc('-'),x=-x;
		static T sta[35],top;top=0;
		do
			sta[++top]=x%10,x/=10;
		while(x);
		while(top)
			pc(sta[top--]^48);
	}
	TP_ void read(T &x,T_&...y){read(x);read(y...);}
	TP void writeln(const T x){write(x);pc('\n');}
	TP void writesp(const T x){write(x);pc(' ');}
	TP_ void writeln(const T x,const T_ ...y){writesp(x);writeln(y...);}
	TP void debugsp(const T x){fprintf(stderr,"%d ",x);}
	TP void debug(const T x){fprintf(stderr,"%d\n",x);}
	TP_ void debug(const T x,const T_...y){debugsp(x);debug(y...);}
	TP inline T max(const T &a,const T &b){return a>b?a:b;}
	TP_ inline T max(const T &a,const T_&...b){return max(a,max(b...));} 
	TP inline T min(const T &a,const T &b){return a<b?a:b;}
	TP_ inline T min(const T &a,const T_&...b){return min(a,min(b...));}
	TP inline void swap(T &a,T &b){static T t;t=a;a=b;b=t;}
	TP inline T abs(const T &a){return a>0?a:-a;}
	#undef TP
	#undef TP_
}
using namespace IO;
using std::cerr;
using PII=std::pair<int,int>;
using LL=long long;
constexpr int N=5e3+10,M=3e5+10,inf=0x3f3f3f3f;
int n,m,st,ed;
LL w[N];
int h[N],gap[N<<1];
struct edge
{
	int y;LL f;int other;
};
std::vector<edge>a[N];
inline void ins(int x,int y,LL f)
{
	a[x].push_back({y,f,(int)a[y].size()});
	a[y].push_back({x,0,(int)a[x].size()-1});
}
struct cmp
{
	inline bool operator()(const int &x,const int &y)const
	{
		return h[x]<h[y];
	}
};
bool bfs()//给所有点一个初始的高度，选择最短路的原因是推流的点最少
{
	static std::priority_queue<PII,std::vector<PII>,std::greater<PII>>q;
	memset(h,0x3f,sizeof(h));
	h[ed]=1;
	q.push({h[ed],ed});
	while(q.size())
	{
		int x=q.top().second;q.pop();
		for(auto k:a[x])
		{
			int y=k.y;
			if(a[y][k.other].f&&h[y]>h[x]+1)
			{
				h[y]=h[x]+1;
				q.push({h[y],y});
			}
		}
	}
	return h[st]!=h[0];
}
bool inq[N];
std::priority_queue<int,std::vector<int>,cmp>q;//按高度排序的大根堆
inline void push(int x)//对 x 点的余流推流出去
{
	for(auto &k:a[x])//这里当前弧优化无用，因为这一条路已被推流完了，要更新另一条路
	{
		int y=k.y;
		if(k.f&&h[y]==h[x]-1)//可以流且是一条合法的推流路径
		{
			LL f=min(w[x],k.f);
			w[x]-=f;w[y]+=f;
			k.f-=f;
			a[y][k.other].f+=f;
			if(y!=st&&y!=ed&&!inq[y]&&h[y]<inf)//加入队列。注意起点和终点不能入队，因为起点有无限余流，终点只接收，没有余流，注意判断高度合法！！！
				q.push(y),inq[y]=1;
			if(!w[x])//没有余流可推了，自然要提前结束
				return ;
		}
	}
}
inline void relabel(int x)//重新给一个高度
{
	h[x]=inf;
	for(auto k:a[x])
	{
		int y=k.y;
		if(k.f&&h[y]+1<h[x])//往尽量低处流，因为最低点是终点
			h[x]=h[y]+1;
	}
}
int HLPP()
{
	if(!bfs())//提前给定高度，加速推流，否则需要再推流时给定，增加遍历数量
		return 0;
	for(int i=1;i<=n;i++)
		if(h[i]<inf)
			++gap[h[i]];//gap 优化，若一个高度已经全部流完，更高的是找不到低处流的
						//并且 gap 需要开到 2n-1，最极端的情况可能会全部流回起点
	h[st]=n;//若其他点流完找不到低处，就要流回起点方向，为防可能流向其他方向，应定为 n，这样其他点在初始情况下是不可能高于起点的
	for(auto &k:a[st])//在起点做一次无限流量的推流
	{
		int y=k.y;
		if(k.f&&h[y]<inf)
		{
			int f=k.f;
			w[st]-=f;w[y]+=f;
			k.f-=f;
			a[y][k.other].f+=f;
			if(y!=st&&y!=ed&&!inq[y]&&h[y]<inf)//加入队列。注意起点和终点不能入队，因为起点有无限余流，终点只接收，没有余流，注意判断高度合法！！！
				q.push(y),inq[y]=1;
		}
	}
	while(q.size())
	{
		int x=q.top();q.pop();inq[x]=0;
		push(x);
		if(w[x])
		{
			if(--gap[h[x]]<=0)//没有该高度了
				for(int i=1;i<=n;i++)
					if(i!=st&&i!=ed&&h[i]>h[x]&&h[i]<n+1)//那么比它更高的就没有低处流了，流回起点
						h[i]=n+1;
			relabel(x);++gap[h[x]];
			q.push(x);inq[x]=1;
		}
	}
	return w[ed];
}
bool _End;
int main()
{
//	fprintf(stderr,"%.2 MBlf\n",(&_End-&_Start)/1048576.0);
	read(n,m,st,ed);
	for(int i=1,x,y,f;i<=m;i++)
	{
		read(x,y,f);
		ins(x,y,f);
	}
	writeln(HLPP());
	return 0;
}
