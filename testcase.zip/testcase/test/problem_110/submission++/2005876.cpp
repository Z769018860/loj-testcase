bool _Start;
#include <bits/stdc++.h>
using namespace std;
#define il inline
#define Tp template<typename T>
#define Ts template<typename T,typename... _T>
Tp il void read(T& x) {
	x=0;bool f=0;char c=getchar();
	for(;!isdigit(c);c=getchar()) f|=c=='-';
	for(;isdigit(c);c=getchar()) x=(x<<1)+(x<<3)+(c^48);
	x=(f?-x:x);
}Ts il void read(T& x,_T&... y) {read(x),read(y...);}
using ll=long long;
const int N=3e6+5;
ll n,p,jc[N],inv[N];
il ll qpow(ll a,ll b) {
	ll res=1;
	while(b) {
		if(b&1) res=res*a%p;
		a=a*a%p;b>>=1;
	}
	return res;
}
bool _End;
int main() {
	fprintf(stderr,"Memory: %.4lf Mib\n",abs(&_End-&_Start)/1048576.0);
	read(n,p);
	jc[0]=1;for(int i=1;i<=n;i++) jc[i]=jc[i-1]*i%p;
	ll all=qpow(jc[n],p-2);
	for(int i=n;i>=1;i--) {
		inv[i]=all*jc[i-1]%p;
		all=all*i%p;
	}
	for(int i=1;i<=n;i++) printf("%lld\n",inv[i]);
	return 0;
}
