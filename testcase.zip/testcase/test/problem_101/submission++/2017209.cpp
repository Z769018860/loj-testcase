// #include <iostream>
// #include <vector>
// #include <algorithm>

// const int N = 1e6 + 2;

// struct Node
// {
//     int v, siz, cnt, p, s[2];
//     void init(int _p, int _v, int app)
//     { p = _p, v = _v, siz = cnt = app; }
// } tr[N];

// void pushup(int id)
// { tr[id].siz = tr[tr[id].s[0]].siz + tr[tr[id].s[1]].siz + tr[id].cnt; }

// std::vector<int> a;
// int n, m, rt, last, ans, idx;
// std::vector<std::pair<int, int>> _a;

// int build(int p, int l, int r)
// {
//     int u = ++ idx;
//     if (l == r)
//     {
//         tr[u].init(p, _a[l].first, _a[l].second);
//         return u;
//     }
//     int mid = (l + r) >> 1;
//     if (l < mid) tr[u].s[0] = build(u, l, mid - 1);
//     if (r > mid) tr[u].s[1] = build(u, mid + 1, r);
//     pushup(u);
// }

// void rotate(int x)
// {
//     int y = tr[x].p, z = tr[y].p;
//     int k = tr[y].s[1] == x;
//     tr[z].s[tr[z].s[1] == y] = x, tr[x].p = z;
//     tr[tr[x].s[k ^ 1]].p = y, tr[y].s[k] = tr[x].s[k ^ 1];
//     tr[x].s[k ^ 1] = y, tr[y].p = x;
//     pushup(y), pushup(x);
// }

// void splay(int x, int k)
// {
//     while (tr[x].p != k)
//     {
//         int y = tr[x].p, z = tr[y].p;
//         if (z != k)
//         {
//             if ((tr[y].s[1] == x) ^ (tr[z].s[1] == y)) rotate(x);
//             else rotate(y);
//         }
//         rotate(x);
//     }

//     if (!k) rt = x;
// }

// void ins(int v)
// {
//     int u = rt, p = 0;
//     while (u)
//     {
//         if (v == tr[u].v)
//         {
//             tr[u].cnt ++ ;
//             pushup(u);
//             splay(u, 0);
//             return;
//         }
//         p = u, u = tr[u].s[v > tr[u].v];
//     }
//     u = ++ idx;
//     if (p) tr[p].s[v > tr[p].v] = u;
//     tr[u].init(p, v, 1), splay(u, 0);
// }

// void del(int v)
// {
//     int u = rt, p = 0;
//     while (true)
//     {
//         if (v == tr[u].v)
//         {
//             tr[u].cnt -- ;
//             if (tr[u].cnt == 0)
//             {

//             }
//             else
//             {

//             }
//         }
//     }
// }

// int main()
// {
//     scanf("%d%d", &n, &m);
//     for (int i = 1, x; i <= n; ++ i)
//         scanf("%d", &x), a.push_back(x);
//     std::sort(a.begin(), a.end());
//     for (int i = 0; i < a.size();)
//     {
//         int j = i;
//         for (; j < a.size() && a[j] == a[i]; ++ j);
//         _a.push_back({a[i], j - i});
//         i = j;
//     }
//     rt = build(0, 0, _a.size() - 1);
//     while (m -- )
//     {
//         int opt, x; scanf("%d%d", &opt, &x);
//         x ^= last;
//         if (last == 1) ins(x);
//         else if (last == 2) del(x);
//         else if (last == 3)
//         {

//         }
//         else if (last == 4)
//         {
//             int u = get_kth(x);
//         }
//     }
// }

#include <iostream>

const int N = 5e3 + 2, INF = 0x3f3f3f3f;

int n, m, S, T;
int to[N << 1], nxt[N << 1], f[N << 1], hd[N], tot = 1;
int d[N], cur[N], q[N];

void edge(int u, int v, int w)
{
    to[ ++ tot] = v, nxt[tot] = hd[u], f[tot] = w, hd[u] = tot;
    to[ ++ tot] = u, nxt[tot] = hd[v], hd[v] = tot;
}

bool bfs()
{
    int hh = 0, tt = 0;
    std::fill(d + 1, d + n + 1, -1);
    d[S] = 0, q[0] = S, cur[S] = hd[S];
    while (hh <= tt)
    {
        int u = q[hh ++ ];
        for (int j = hd[u]; j; j = nxt[j])
        {
            if (d[to[j]] == -1 && f[j])
            {
                d[to[j]] = d[u] + 1;
                cur[to[j]] = hd[to[j]];
                if (to[j] == T) return true;
                q[ ++ tt] = to[j];
            }
        }
    }
    return false;
}

int find(int u, int limit)
{
    if (u == T) return limit;
    int flow = 0;
    for (int j = cur[u]; j && flow < limit; j = nxt[j])
    {
        cur[u] = j;
        if (d[to[j]] == d[u] + 1 && f[j])
        {
            int t = find(to[j], std::min(f[j], limit - flow));
            if (!t) d[to[j]] = -1;
            f[j] -= t, f[j ^ 1] += t, flow += t;
        }
    }
    return flow;
}

long long dinic()
{
    long long res = 0;
    int flow;
    while (bfs()) while ((flow = find(S, INF))) res += flow;
    return res;
}

int main()
{
    scanf("%d%d%d%d", &n, &m, &S, &T);
    for (int i = 1; i <= m; ++ i)
    {
        int u, v, c; scanf("%d%d%d", &u, &v, &c);
        edge(u, v, c);
    }
    printf("%lld\n", dinic());
    return 0;
}