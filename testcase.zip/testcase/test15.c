int main()
{
  int n,i=2,product=1;
  //scanf("%d",&n);
  while(i<=n)
  {
    product=i*product;
    i=i+1;
  }
  //printf("The product from 1 to %d is %d\n",n,product);

  return 0;
}