
int main()
{
    int i,j,n,m;
    int k;
    //scanf("%d",&m);
    while(m)
    {
        m=m-1;
        //scanf("%d",&n);
        for(i=n;i>=1;i=i-1)
        {
            for(j=i;j<n;j=j+1)
                k=0;
            for(j=1;j<=2*i-1;j=j+1)
                k=1;
            k=2;
        }
    }
    return 0;
}