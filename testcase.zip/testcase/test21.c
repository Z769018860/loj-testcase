void BubbleSort(){
    int array[5];
    int len;
    int i,j,tem;
    //外层循环控制 排序的趟数 n个元素排序需要循环n-1次 【1】 
    for(int i=0;i<len-1;i=i+1) {
        //内层循环控制比较的次数 n个元素第i趟比较n-i次 【2】
        for(int j=0;j<len-1-i;j=j+1) {
            //比较相邻的元素大小 目的：将最大的元素选出到移动到最后 
            if(array[j]>array[j+1]){
                tem = array[j];
                array[j] = array[j+1];
                array[j+1] = tem;
            }
        }
    }
} 
