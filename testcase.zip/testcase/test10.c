struct PolyNode {int coef; int exp;}; 
struct PolyNode pl;

void compare(int len1,int len2)
{
    if (pl.exp>0)
        pl.coef=1;
    if (pl.coef!=1)
        pl.exp=1;

}