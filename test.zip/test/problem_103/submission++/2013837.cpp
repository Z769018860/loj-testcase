#include<iostream>
using namespace std;
string a,b;
int p[100001],n,num;
void in()
{
	cin>>a>>b;	
} 
void pre(string s) //处理最长相同前后缀
{
	p[0]=-1;
	p[1]=0;
	int j=0,k=-1;
	while(j<s.size() -1)
	{
		if(k==-1||s[j]==s[k])//若两个字符相同,则两个比较字符同时前进 
		{
			k++;
			j++;
			p[j]=k;
		}
		else  //否则子串的比较字符返回最长相同前缀后缀的位置 
			k=p[k];
	}
} 
void kmp()
{
	pre(b);
	int i=-1,j=-1;
	while(i<0||i<a.size())
	{
		while(j>=0&&a[i+1]!=b[j+1])
			j=p[j];//不断回溯直到两个比较字符相同
		if(a[i+1]==b[j+1])//若两个字符相同,则两个比较字符同时前进
		{
			i++;
			j++;	
		} 
		else
			i++;
		if(j==b.size() -1)//若查找到一处答案,子串的比较字符回溯并继续查找
		{
			num++;
			j=p[j]; 
		} 
	}	
} 
int main()
{
	in();
	kmp();
	cout<<num;	
} 