#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define N 1000010
int sa[N], rank[N], sa2[N], cnt[N], cache[N];
char s[N];

int cmp(int *oldrk, int a, int b, int w) {  // 检测双关键字是否相同
	return oldrk[a] == oldrk[b] && oldrk[a+w] == oldrk[b+w];
}

void DA(char *s, int n, int m) {
    int i, p, w, *rk = rank, *pn = sa2, *t;
    // 1. 第一轮单字符排序(rank 以ASCII码而定)
	for (i = 0; i < n; i++) cnt[rk[i] = s[i]]++;
	for (i = 1; i <= m; i++) cnt[i] += cnt[i-1];
	for (i = n - 1; i >= 0; i--) sa[--cnt[rk[i]]] = i;  // rk[i]即ASCII,桶位置
	// 2. 倍增算法
	for (p = w = 1; p < n; w *= 2, m = p) {
		for (i = 0; i <= m; i++) cnt[i] = 0;  // 计数器清空
		// (1) 第二关键字排序：上轮得到（关键字2 长度为 w 的 sa2(pn) 排序)
		for (p = 0, i = n - w; i < n; i++) pn[p++] = i;
		for (i = 0; i < n; i++) if (sa[i] >= w) pn[p++] = sa[i] - w;
		for (i = 0; i <= m; i++) cnt[i] = 0;  // 计数器清空
		// (2) 第一关键字排序：对上面排序后的 sa2 再次按照  rk[pn[i]] 比较大小(LSD桶排序)
		for (i = 0; i < n; i++) cnt[cache[i] = rk[pn[i]]]++;  // 计数 关键字1 出现次数
		for (i = 1; i <= m; i++) cnt[i] += cnt[i-1];  // 前缀和累加
		for (i = n - 1; i >= 0; i--) sa[--cnt[cache[i]]] = pn[i];
		// (3) 更新相对排名：此时 pn 可用于覆盖 rank 暂存
		for (t = pn, pn = rk, rk = t, rk[sa[0]] = 0, p = i = 1; i < n; i++) {
			rk[sa[i]] = (cmp(pn, sa[i-1], sa[i], w) ? p - 1 : p++);
		}
    }
    for (i = 0; i < n; i++) printf("%d ", sa[i] + 1);
}

int main () {
	scanf("%s", s);
	DA(s, strlen(s), 256);
	return 0;
}