/*#include <bits/stdc++.h>
#define int long long
#define endl '\n'
#define IOS ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
#define lowbit(x) (x&(-x))
using namespace std;
const int N=8e6+10;

const int mod=998244353;
int fa[N];//存储该节点的父节点
int sum[N];
int dist[N];
int find(int x)
{
    if(fa[x]==x)
        return x;
    else {
        int tt=find(fa[x]);
        dist[x]+=dist[fa[x]];
        fa[x]=tt;
        return fa[x];
    }
}
void add(int x,int y)
{
    int xx=find(x);
    int yy=find(y);
    dist[xx]=sum[yy];
    fa[xx]=yy;
    sum[yy]+=sum[xx];
}
void solve()
{
    for(int i=1;i<=30005;i++){
        fa[i]=i;
        sum[i]=1;
        dist[i]=0;
    }
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        char op;
        int x,y;
        cin>>op>>x>>y;
        if(op=='M'){
            add(x,y);
        }
        else {
            int xx=find(x);
            int yy=find(y);
            if(xx!=yy){
                cout << -1 <<endl;
            }
            else {
                if(x==y){
                    cout << 0 <<endl;
                }
                else {
                    cout << abs(dist[x]-dist[y])-1 <<endl;
                }
            }
        }
    }
}
signed main()
{
    IOS;
    int T=1;
    //cin>>T;
    while(T--){
        solve();
    }
    return 0;
}*/

#include<iostream>
using namespace std;
int fa[4000010];
long long ans=0;
int p=0,temp;
const long long mod=998244353;
int find(int i)
{
	if(fa[i] == i)
		return i;
	else{
		fa[i] = find(fa[i]);
		return fa[i];
}
}
void unionn(int x,int y)
{
	int xx=find(x);
	int yy=find(y);
	if(xx!=yy)
		fa[yy]=xx;
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int op,u,v,n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		fa[i]=i;
	while(m--)
	{
		cin>>op>>u>>v;
		if(op==0)
			unionn(u,v);
		else if(op==1)
		{
			if(find(u)==find(v))
			{
				ans*=2;
				ans+=1;
				ans%=mod;
			}
			else
			{
			 	ans*=2;
			 	ans%=mod;
			}
		}
	}
	cout<<ans%mod;
	return 0;
}
