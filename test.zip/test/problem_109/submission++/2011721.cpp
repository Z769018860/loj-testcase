/*#include <bits/stdc++.h>
#define int long long
#define endl '\n'
#define IOS ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
#define lowbit(x) (x&(-x))
using namespace std;
const int N=8e6+10;

const int mod=998244353;
int fa[N];//存储该节点的父节点
int sum[N];
int dist[N];
int find(int x)
{
    if(fa[x]==x)
        return x;
    else {
        int tt=find(fa[x]);
        dist[x]+=dist[fa[x]];
        fa[x]=tt;
        return fa[x];
    }
}
void add(int x,int y)
{
    int xx=find(x);
    int yy=find(y);
    dist[xx]=sum[yy];
    fa[xx]=yy;
    sum[yy]+=sum[xx];
}
void solve()
{
    for(int i=1;i<=30005;i++){
        fa[i]=i;
        sum[i]=1;
        dist[i]=0;
    }
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        char op;
        int x,y;
        cin>>op>>x>>y;
        if(op=='M'){
            add(x,y);
        }
        else {
            int xx=find(x);
            int yy=find(y);
            if(xx!=yy){
                cout << -1 <<endl;
            }
            else {
                if(x==y){
                    cout << 0 <<endl;
                }
                else {
                    cout << abs(dist[x]-dist[y])-1 <<endl;
                }
            }
        }
    }
}
signed main()
{
    IOS;
    int T=1;
    //cin>>T;
    while(T--){
        solve();
    }
    return 0;
}*/

#include<iostream>
using namespace std;
const int N=8e6+10;
int fa[N];
int find(int n)
{
	if(fa[n]==n)
	{
		return n;
	}
	else
	{
		fa[n]=find(fa[n]);
		return fa[n];
	}

}
void add(int i,int j)
{
	int fi=find(i);
	int fj=find(j);
	if(fj!=fi)
	{
		fa[fi]=fj;
	}
}
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n,m;
	cin>>n>>m;
	for(int i=0;i<n;i++)
	{
		fa[i]=i;
	}
	int ans=0;
	for(int i=1;i<=m;i++)
	{
		int a,b,c;
		cin>>a>>b>>c;
		if(a==0)
		{
			add(b,c);
		}
		else
		{
			int x=find(b);
			int y=find(c);
			if(x==y)
			{
				ans=ans*2+1;
			}
			else
			{
				ans*=2;
			}
			ans%=998244353;
		}
	}
	ans=ans%998244353;
	cout<<ans<<endl;
}
