#include<regex.h>
char s[26];m[2],r[99];main(){for(;gets(s);)puts(regexec(r,gets(s),1,m,regcomp(r,s,1))|*m|s[m[1]]?"No":"Yes");}