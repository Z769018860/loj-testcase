#include<stdio.h>
#include<string.h>

int n;
char s[2002000];
int main(){
	scanf("%s",s);
	n = strlen(s);

    // i is the minimum prefix (choose the longest for common prefixed suffixes)
    // k is the first unseen character
    // j is one period of s[i : k] before j
    for (int i = 0, j = 0, k = 1; i < n;) {
        // printf("%d %d %d\n", i, j, k);
        if (k > n || s[j] > s[k]) {
            for(; i <= j; i += k - j)
                printf("%d ", i + k - j);
            j = i;
            k = i + 1;
        }
        else if (s[j] < s[k]) j = i, k++;
        else j++, k++;
    }
}