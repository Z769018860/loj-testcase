#include "shm.h"
using namespace std;
unsigned int plus(unsigned int a, unsigned int b) {
    return a + b;
}