#include "shm.h"
unsigned int plus(unsigned int a, unsigned int b) {
	return a + b;
}